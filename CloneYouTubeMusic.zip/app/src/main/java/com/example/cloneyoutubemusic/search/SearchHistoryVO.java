package com.example.cloneyoutubemusic.search;

public class SearchHistoryVO {
    private String txt;

    public SearchHistoryVO(String txt) {
        this.txt = txt;
    }

    public String getTxt() {
        return txt;
    }

    public void setTxt(String txt) {
        this.txt = txt;
    }
}
