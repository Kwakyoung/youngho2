package com.example.cloneyoutubemusic.Home.DTO;

public class QuickDTO {
    private int item_music, item_music1,item_music2,item_music3;
    private String item_title,item_title1,item_title2,item_title3,
                    item_singer,item_singer1,item_singer2,item_singer3;

    public QuickDTO(int item_music, int item_music1, int item_music2, int item_music3, String item_title, String item_title1, String item_title2, String item_title3,
                    String item_singer, String item_singer1, String item_singer2, String item_singer3) {
        this.item_music = item_music;
        this.item_music1 = item_music1;
        this.item_music2 = item_music2;
        this.item_music3 = item_music3;
        this.item_title = item_title;
        this.item_title1 = item_title1;
        this.item_title2 = item_title2;
        this.item_title3 = item_title3;
        this.item_singer = item_singer;
        this.item_singer1 = item_singer1;
        this.item_singer2 = item_singer2;
        this.item_singer3 = item_singer3;
    }

    public int getItem_music() {
        return item_music;
    }

    public void setItem_music(int item_music) {
        this.item_music = item_music;
    }

    public int getItem_music1() {
        return item_music1;
    }

    public void setItem_music1(int item_music1) {
        this.item_music1 = item_music1;
    }

    public int getItem_music2() {
        return item_music2;
    }

    public void setItem_music2(int item_music2) {
        this.item_music2 = item_music2;
    }

    public int getItem_music3() {
        return item_music3;
    }

    public void setItem_music3(int item_music3) {
        this.item_music3 = item_music3;
    }

    public String getItem_title() {
        return item_title;
    }

    public void setItem_title(String item_title) {
        this.item_title = item_title;
    }

    public String getItem_title1() {
        return item_title1;
    }

    public void setItem_title1(String item_title1) {
        this.item_title1 = item_title1;
    }

    public String getItem_title2() {
        return item_title2;
    }

    public void setItem_title2(String item_title2) {
        this.item_title2 = item_title2;
    }

    public String getItem_title3() {
        return item_title3;
    }

    public void setItem_title3(String item_title3) {
        this.item_title3 = item_title3;
    }

    public String getItem_singer() {
        return item_singer;
    }

    public void setItem_singer(String item_singer) {
        this.item_singer = item_singer;
    }

    public String getItem_singer1() {
        return item_singer1;
    }

    public void setItem_singer1(String item_singer1) {
        this.item_singer1 = item_singer1;
    }

    public String getItem_singer2() {
        return item_singer2;
    }

    public void setItem_singer2(String item_singer2) {
        this.item_singer2 = item_singer2;
    }

    public String getItem_singer3() {
        return item_singer3;
    }

    public void setItem_singer3(String item_singer3) {
        this.item_singer3 = item_singer3;
    }
}
